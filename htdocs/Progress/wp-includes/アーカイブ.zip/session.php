<?php
/**
 * Session API
 *
 * @since 4.0.0
 */

_deprecated_file( basename( __FILE__ ), '4.7.0' );

require_once( ABSPATH . WPINC . '/class-wp-session-tokens.php' );
require_once( ABSPATH . WPINC . '/class-wp-user-meta-session-tokens.php' );